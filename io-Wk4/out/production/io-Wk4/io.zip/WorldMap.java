public class WorldMap {
    public static void main(String[] args) {

        int x = StdIn.readInt();
        int y = StdIn.readInt();

        StdDraw.setCanvasSize(x, y);
        StdDraw.setXscale(0, x);
        StdDraw.setYscale(0, y);

        StdDraw.enableDoubleBuffering();

        while (!StdIn.isEmpty()) {

            StdIn.readString();

            int verts = StdIn.readInt();
            double[] xCoords = new double[verts];
            double[] yCoords = new double[verts];

            for (int i = 0; i < verts; i++) {

                xCoords[i] = StdIn.readDouble();
                yCoords[i] = StdIn.readDouble();
            }

            StdDraw.polygon(xCoords, yCoords);
        }

        StdDraw.show();
    }
}
