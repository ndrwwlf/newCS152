public class GeneralizedHarmonic {
    public static void main(String[] args) {

        double n = Double.parseDouble(args[0]);
        double r = Double.parseDouble(args[1]);
        double h = 0;
        int i = 1;

        for (i = 1; i <= n; i++) {
            h = h + (1) / Math.pow(i, r);
        }

        System.out.println(h);
    }
}
