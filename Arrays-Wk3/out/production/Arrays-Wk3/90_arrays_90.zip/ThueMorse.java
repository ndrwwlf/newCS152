public class ThueMorse {
    public static void main(String[] args) {

        int matrixDim = Integer.parseInt(args[0]);
//        int n = (int) Math.pow((double) matrixDim, (double) 2);
        boolean[] tMArr = new boolean[]{false};
        int nextP2;

        /*// calculate the position of the last set bit of `n`
        int lg = (int) (Math.log(matrixDim - 1) / Math.log(2));

        // next power of two will have a bit set at position `lg+1`.
        nextP2 = 1 << lg + 1;*/

        /*boolean good = false;

        int width = matrixDim;
        double log = Math.log(width) / Math.log(2);
        long roundLog = Math.round(log);
        int powerOfTwo = (int) (Math.pow(2, roundLog));

        while (!good) {
//            int width = matrixDim;
//            double log = Math.log(width) / Math.log(2);
//            long roundLog = Math.round(log);
//            int powerOfTwo = (int) (Math.pow(2, roundLog));

            if (powerOfTwo >= width) {
                good = true;
            } else {
                width++;
                log = Math.log(width) / Math.log(2);
                roundLog = Math.round(log);
                powerOfTwo = (int) (Math.pow(2, roundLog));
            }
        }*/

//        long a = Long.highestOneBit(matrixDim);
//        int powerOfTwo = (int) (matrixDim > a ? a << 1 : a);
//
        int powerOfTwo = matrixDim;
        
        if (matrixDim != 2) {
            double log = Math.ceil(Math.log(matrixDim) / Math.log(2));
            powerOfTwo = (int) Math.pow(log, 2);
        }

//        int logNextP2 = ((int) (Math.log(nextP2) / Math.log(2)));
        for (int i = 0; i < powerOfTwo; i++) {

            boolean[] copy = new boolean[2 * tMArr.length];

            for (int j = 0; j < tMArr.length; j++) {
                copy[j] = tMArr[j];
            }
            for (int k = tMArr.length; k < 2 * tMArr.length; k++) {
                copy[k] = !tMArr[k - tMArr.length];
            }

            tMArr = copy;
        }

//        for (int i = 0; i < matrixDim; i++) {
//            for (int j = i * matrixDim; j < (i + 1) * matrixDim; j++) {
//                if (!tMArr[j]) {
//                    StdOut.print("+  ");
//                } else {
//                    StdOut.print("-  ");
//                }
//            }
//            StdOut.println();
//        }

        for (int i = 0; i < matrixDim; i++) {
            for (int j = i * powerOfTwo; j < (i * powerOfTwo) + matrixDim; j++) {
                if (!tMArr[j]) {
                    StdOut.print("+  ");
                } else {
                    StdOut.print("-  ");
                }
            }
            StdOut.println();
        }

    }
}
