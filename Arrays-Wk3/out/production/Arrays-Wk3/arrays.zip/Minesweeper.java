public class Minesweeper {
    public static void main(String[] args) {

        int m = Integer.parseInt(args[0]);
        int n = Integer.parseInt(args[1]);
        int bombs = Integer.parseInt(args[2]);

        boolean[][] grid = new boolean[m][n];
//        int[][] bombCount = new int[m][n];

        //fill grid
        while (bombs > 0) {

//            int x = StdRandom.uniformInt(m);
//            int y = StdRandom.uniformInt(n);
            int x = (int) (Math.random() * m);
            int y = (int) (Math.random() * n);

            if (!grid[x][y]) {

                grid[x][y] = true;
                bombs--;
            }

        }

        for (int i = 0; i < grid.length; i++) {

            for (int j = 0; j < grid[i].length; j++) {

                if (grid[i][j]) {
                    StdOut.print("B  ");
                } else {
                    StdOut.print("O  ");
                }
            }

            StdOut.println();
        }

    }
}
